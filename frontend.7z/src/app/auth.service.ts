import { Injectable } from '@angular/core'
import { HttpClient, HttpHeaders } from '@angular/common/http'
import {Router} from '@angular/router'

@Injectable()
export class AuthService {
    rootUrl = "http://localhost:11111";
    NAME_KEY = 'name';
    TOKEN_KEY = 'token';
    constructor(private http: HttpClient, private router:Router) {

    }
    get name() {
        return localStorage.getItem(this.NAME_KEY);
    }
    get isAuthenticated(){
        return !!localStorage.getItem(this.TOKEN_KEY);
    }
    register(credentials) {
        console.log(credentials);
        return this.http.post<any>("http://localhost:11111/api/Account/Register", credentials).subscribe(result => {
            this.userAuthentication(credentials.email, credentials.password).subscribe(res => {
                this.authenticate(res);
            },
                error => {
                    console.log(error);
                }
            );
        },
            error => {
                console.log(error);
            });
    }
    userAuthentication(userName, password) {
        var data = "username=" + userName + "&password=" + password + "&grant_type=password";
        var reqHeader = new HttpHeaders({ 'Content-Type': 'application/x-www-urlencoded', 'No-Auth': 'True' });
        return this.http.post(this.rootUrl + '/token', data, { headers: reqHeader });
    }
    authenticate(res) {
        var authresponse = res;
        if (!authresponse.access_token)
            return;
        localStorage.setItem(this.TOKEN_KEY, authresponse.access_token);
        localStorage.setItem(this.NAME_KEY, authresponse.userName);
        this.router.navigate(['/']);
    }
    logout()
    {
        localStorage.removeItem(this.NAME_KEY);
        localStorage.removeItem(this.TOKEN_KEY);
    }
    login(userName, password)
    {
        this.userAuthentication(userName, password).subscribe(res => {
            this.authenticate(res);
        },
            error => {
                console.log(error);
            }
        );
    }
}